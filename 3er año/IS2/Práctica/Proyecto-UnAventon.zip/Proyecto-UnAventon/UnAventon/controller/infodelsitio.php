<?php

include "../view/infodelsitio.html";
if(isset($_GET['idautoincremental'])) {

$id= ($_GET["idautoincremental"]);

	}
	



?>