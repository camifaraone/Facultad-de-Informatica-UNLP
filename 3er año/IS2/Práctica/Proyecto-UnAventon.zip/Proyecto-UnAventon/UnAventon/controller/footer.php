<?php
include "../view/footer.html";
?>