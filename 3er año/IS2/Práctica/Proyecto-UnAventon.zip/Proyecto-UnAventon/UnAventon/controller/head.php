<?php
include "../view/head.html";
?>