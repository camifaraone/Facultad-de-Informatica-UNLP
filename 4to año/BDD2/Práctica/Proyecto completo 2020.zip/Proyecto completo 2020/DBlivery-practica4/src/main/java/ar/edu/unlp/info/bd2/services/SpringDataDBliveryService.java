package ar.edu.unlp.info.bd2.services;
import ar.edu.unlp.info.bd2.model.*;

import java.util.*;

import ar.edu.unlp.info.bd2.repositories.DBliveryException;
import ar.edu.unlp.info.bd2.repositories.spring.data.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service("springDataDBliveryService")
@Transactional(readOnly=false)
public class SpringDataDBliveryService implements DBliveryService, DBliveryStatisticsService {

	@Autowired
    private CanceledRepository canceledRepository;
		
	@Autowired
    private DeliveredRepository deliveredRepository;
	
	@Autowired
    private OrderLineRepository orderLineRepository;
	
	@Autowired
    private OrderRepository orderRepository;
	
	@Autowired
    private OrderStateRepository orderStateRepository;
	
	@Autowired
    private PendingRepository pendingRepository;
	
	@Autowired
    private PriceRepository priceRepository;
	
	@Autowired
    private ProductRepository productRepository;
	
	@Autowired
    private SendedRepository sendedLineRepository;
	
	@Autowired
    private SupplierRepository supplierRepository;
		
	@Autowired
    private UserRepository userRepository;


	@Override
	public Product createProduct(String name, Float price, Float weight, Supplier supplier) {
		Product p = new Product(name, weight, supplier, price);
		return this.productRepository.save(p);
		
	}


	@Override
	public Product createProduct(String name, Float price, Float weight, Supplier supplier, Date date) {
		Product p = new Product(name, weight, supplier, price, date);
		return this.productRepository.save(p);
	}


	@Override
	public Supplier createSupplier(String name, String cuil, String address, Float coordX, Float coordY) {
		Supplier s = new Supplier(name, cuil, address, coordX, coordY);
		return this.supplierRepository.save(s);
	}


	@Override
	public User createUser(String email, String password, String username, String name, Date dateOfBirth) {
		User u = new User(email, password, username, name, dateOfBirth);
		return this.userRepository.save(u);
	}


	@Override
	public Product updateProductPrice(Long id, Float price, Date startDate) throws DBliveryException {
		Product p =  (Product)this.productRepository.findProductById(id);
		Price pri = new Price(price, startDate);
		p.setPrice(price);
		p.getPrices().add(pri);
		this.priceRepository.save(pri);
		return this.productRepository.save(p);
	}


	@Override
	public Optional<User> getUserById(Long id) {
		return this.userRepository.findById(id);
	}


	@Override
	public Optional<User> getUserByEmail(String email) {
		return this.userRepository.findUserByEmail(email);
	}


	@Override
	public Optional<User> getUserByUsername(String username) {
		return this.userRepository.findUserByUsername(username);
	}


	@Override
	public Optional<Order> getOrderById(Long id) {
		return this.orderRepository.findById(id);
	}


	@Override
	public Order createOrder(Date dateOfOrder, String address, Float coordX, Float coordY, User client) {
		Order o = new Order(dateOfOrder, address, coordX, coordY, client);
		return this.orderRepository.save(o);
	}


	@Override
	public Order addProduct(Long order, Long quantity, Product product) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		OrderLine ol = o.addOrderLine(quantity, product);
		//this.orderLineRepository.save(ol);
		return this.orderRepository.save(o);
	}


	@Override
	public Order deliverOrder(Long order, User deliveryUser) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		if(o.getOrderLines().isEmpty()) 
			throw new DBliveryException("The order can't be delivered");
		o.deliverOrder(deliveryUser);
		return this.orderRepository.save(o);
	}


	@Override
	public Order deliverOrder(Long order, User deliveryUser, Date date) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		if(o.getOrderLines().isEmpty()) 
			throw new DBliveryException("The order can't be delivered");
		o.deliverOrder(deliveryUser, date);
	    return this.orderRepository.save(o);
	}


	@Override
	public Order cancelOrder(Long order) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		o.cancel();
		return this.orderRepository.save(o);
	}


	@Override
	public Order cancelOrder(Long order, Date date) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		o.cancel(date);
		return this.orderRepository.save(o);
	}


	@Override
	public Order finishOrder(Long order) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		o.finish();
		return this.orderRepository.save(o);
	}


	@Override
	public Order finishOrder(Long order, Date date) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		o.finish(date);
		return this.orderRepository.save(o);
	}


	@Override
	public boolean canCancel(Long order) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		return o.canCancel();
	}


	@Override
	public boolean canFinish(Long id) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(id);
		return o.canFinish();
	}


	@Override
	public boolean canDeliver(Long order) throws DBliveryException {
		Order o = this.orderRepository.findOrderById(order);
		if(o.getProducts().isEmpty())return false;
		return o.canDeliver();
	}


	@Override
	public OrderState getActualStatus(Long order) {
		Order o = this.orderRepository.findOrderById(order);
		return o.getOrderState();
	}


	@Override
	public List<Product> getProductsByName(String name) {
		return this.productRepository.findByNameContaining(name);
	}


	@Override
	public Product getMaxWeigth() {
		return this.productRepository.findFirstByOrderByWeightDesc();
	}


	@Override
	public List<Order> getAllOrdersMadeByUser(String username) {
		Optional<User> client = this.getUserByUsername(username);
		return this.orderRepository.findAllOrderByClient(client.get());
	}


	@Override
	public List<Order> getPendingOrders() {
		return this.orderRepository.findAllOrderByOrderStateName("Pending");
	}


	@Override
	public List<Order> getSentOrders() {
		return this.orderRepository.findAllOrderByOrderStateName("Sended");
	}


	@Override
	public List<Order> getDeliveredOrdersInPeriod(Date startDate, Date endDate) {
		return this.orderRepository.findAllOrderByOrderStateNameAndOrderStateStartDateAfterAndOrderStateStartDateBefore("Delivered", startDate, endDate);
	}


	@Override
	public List<Order> getDeliveredOrdersForUser(String username) {
		Optional<User> client = this.getUserByUsername(username);
		return this.orderRepository.findAllOrderByOrderStateNameAndClient("delivered", client.get());
	}


	@Override
	public List<Product> getProductsOnePrice() {
		return this.productRepository.findProductsOnePrice();
		
	}


	@Override
	public List<Product> getSoldProductsOn(Date day) {
		List<Order> os = this.orderRepository.findAllOrderByDateOfOrder(day);
		List<Product> products = new Vector<Product>();
		for (Order order : os) 
		{
			for (OrderLine ol : order.getOrderLines()) 
			{
				products.add(ol.getProduct());
			}
		}
		return products;
	}
	
	
}
