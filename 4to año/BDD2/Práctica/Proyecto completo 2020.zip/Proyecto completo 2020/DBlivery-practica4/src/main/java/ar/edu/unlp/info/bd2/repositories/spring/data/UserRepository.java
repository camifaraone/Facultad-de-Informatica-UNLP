package ar.edu.unlp.info.bd2.repositories.spring.data;

import java.util.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import ar.edu.unlp.info.bd2.model.User;

@Transactional(readOnly = true)
@Repository
public interface UserRepository extends CrudRepository <User,Long>{
	User findUserById(Long id) ;
	Optional<User> findUserByEmail(String email);
	Optional<User> findUserByUsername(String username);

}
