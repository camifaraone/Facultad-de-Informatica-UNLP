package ar.edu.unlp.info.bd2.repositories.spring.data;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import ar.edu.unlp.info.bd2.model.OrderState;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional(readOnly = true)
@Repository
public interface OrderStateRepository  extends CrudRepository <OrderState,Long>{
	
}
