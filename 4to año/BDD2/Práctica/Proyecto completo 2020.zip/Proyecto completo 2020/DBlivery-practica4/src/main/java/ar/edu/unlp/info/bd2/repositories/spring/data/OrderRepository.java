package ar.edu.unlp.info.bd2.repositories.spring.data;

import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.info.bd2.model.Order;
import ar.edu.unlp.info.bd2.model.User;
@Transactional(readOnly = true)
@Repository
public interface OrderRepository extends CrudRepository<Order,Long>
{
	Order findOrderById(Long id);
	List<Order> findAllOrderByClient(User client);
	List<Order> findAllOrderByOrderStateName(String stateName);
	List<Order> findAllOrderByOrderStateNameAndClient(String stateName, User client);
	List<Order> findAllOrderByOrderStateNameAndOrderStateStartDateAfterAndOrderStateStartDateBefore(String stateName, Date startDate, Date endDate);
	List<Order> findAllOrderByDateOfOrder(Date dateOfOrder);
}
