package ar.edu.unlp.info.bd2.repositories.spring.data;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.info.bd2.model.Product;


@Transactional(readOnly = true)
@Repository
public interface ProductRepository extends CrudRepository<Product,Long>{
	Product findProductById(Long id);
	List<Product> findByNameContaining(String name);
	
	Product findFirstByOrderByWeightDesc();
	
	@Query("SELECT p FROM Product p JOIN p.prices pri GROUP BY p HAVING COUNT(pri.id) < 2")
	List<Product> findProductsOnePrice();

}


