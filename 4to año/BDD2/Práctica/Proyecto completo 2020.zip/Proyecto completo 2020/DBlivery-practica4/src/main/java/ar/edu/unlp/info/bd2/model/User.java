package ar.edu.unlp.info.bd2.model;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "User")
public class User {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String name;
    private String email;
    private String password;
    private Date dateOfBirth;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "client", cascade = CascadeType.ALL)
    private Set<Order> orders =new HashSet<Order>();

    public User() {};

    public User(String email, String password, String username, String name, Date dateOfBirth) {
        setUsername(username);
        setName(name);
        setEmail(email);
        setPassword(password);
        setDateOfBirth(dateOfBirth);
    };

	public void setOrders(Set<Order> orders) {
		this.orders = orders;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Long getId() {
        return id;
    }

    public void setId(long userId) {
        this.id = userId;
    }

    public Set<Order> getOrders() {
        return orders;
    }

    public void setOrders(Order order) {
        this.orders.add(order);
    }

    public void addOrder(Order order) {
        setOrders(order);
    }

    public Order createOrder(Date dateOfOrder, String address, Float coordX,  Float coordY) {
        Order newOrder = new Order(dateOfOrder, address, coordX,  coordY, this);
        addOrder(newOrder);
        return newOrder;
    }
}
