package ar.edu.unlp.info.bd2.repositories.spring.data;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.unlp.info.bd2.model.Canceled;


@Transactional(readOnly = true)
@Repository
public interface CanceledRepository extends CrudRepository <Canceled,Long>{
	

}
