package ar.edu.unlp.info.bd2.repositories;

import static com.mongodb.client.model.Aggregates.group;
import static com.mongodb.client.model.Aggregates.limit;
import static com.mongodb.client.model.Aggregates.lookup;
import static com.mongodb.client.model.Aggregates.match;
import static com.mongodb.client.model.Aggregates.replaceRoot;
import static com.mongodb.client.model.Aggregates.sort;
import static com.mongodb.client.model.Aggregates.unwind;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.regex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Spliterators;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;

import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Indexes;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.geojson.Point;
import com.mongodb.client.model.geojson.Position;

import ar.edu.unlp.info.bd2.model.Order;
import ar.edu.unlp.info.bd2.model.Product;
import ar.edu.unlp.info.bd2.model.Supplier;
import ar.edu.unlp.info.bd2.model.User;
import ar.edu.unlp.info.bd2.mongo.Association;
import ar.edu.unlp.info.bd2.mongo.PersistentObject;

public class DBliveryMongoRepository {

    @Autowired private MongoClient client;

    public void saveAssociation(PersistentObject source, PersistentObject destination, String associationName) {
        Association association = new Association(source.getObjectId(), destination.getObjectId());
        this.getDb()
                .getCollection(associationName, Association.class)
                .insertOne(association);
    }

    public MongoDatabase getDb() {
        return this.client.getDatabase("bd2_grupo12");
    }

    public <T extends PersistentObject> List<T> getAssociatedObjects(
            PersistentObject source, Class<T> objectClass, String association, String destCollection) {
        AggregateIterable<T> iterable =
                this.getDb()
                        .getCollection(association, objectClass)
                        .aggregate(
                                Arrays.asList(
                                        match(eq("source", source.getObjectId())),
                                        lookup(destCollection, "destination", "_id", "_matches"),
                                        unwind("$_matches"),
                                        replaceRoot("$_matches")));
        Stream<T> stream =
                StreamSupport.stream(Spliterators.spliteratorUnknownSize(iterable.iterator(), 0), false);
        return stream.collect(Collectors.toList());
    }

    public Product findProductById(ObjectId id) {
        Bson filter = eq("_id", id);
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        return collection.find(filter).first();
    }

    public User findUserById(ObjectId id) {
        Bson filter = eq("_id", id);
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        return collection.find(filter).first();
    }

    public User findUserByEmail(String email) {
        Bson filter = eq("email", email);
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        return collection.find(filter).first();
    }

    public User findUserByUsername(String username) {
        Bson filter = eq("username", username);
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        return collection.find(filter).first();
    }

    public Order findOrderById(ObjectId orderId) {
        Bson filter = eq("_id", orderId);
        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
        Order result =  collection.find(filter).first();
        if (result.getId() != null){
            return result;
        }
        return null;
    }

    public Supplier findSupplierById(ObjectId supplierId) {
        Bson filter = eq("_id", supplierId);
        MongoCollection<Supplier> collection = getDb().getCollection("suppliers", Supplier.class);
        Supplier result =  collection.find(filter).first();
        if (result.getId() != null){
            return result;
        }
        return null;
    }

    public List<Product> getProductsByName(String name) {
        Bson filter = regex("name", name);
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        FindIterable<Product> productsItarable = collection.find(filter);
        List<Product> productsByName = new ArrayList<Product>();
        Iterator productIterator = productsItarable.iterator();
        while (productIterator.hasNext()){
            Product aProduct = (Product) productIterator.next();
                productsByName.add(aProduct);
        }
        return productsByName;
    }

    public Product saveProduct(Product product) {
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        collection.insertOne(product);
        return product;
    }

    public Supplier saveSupplier(Supplier supplier) {
        MongoCollection<Supplier> collection = getDb().getCollection("suppliers", Supplier.class);
        collection.insertOne(supplier);
        return supplier;
    }

    public User saveUser(User user) {
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        collection.insertOne(user);
        return user;
    }

    public Order saveOrder(Order order) {
        ObjectId objectId = new ObjectId();
        order.setObjectId(objectId);
        User cli = this.findUserByEmail(order.getClient().getEmail());
        saveAssociation(order, cli, "orderClientUser");
        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
        collection.insertOne(order);
        return order;
    }

    public Product updateProduct(Product product) {
        Bson filter = eq("_id", product.getObjectId());
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        collection.replaceOne(filter, product);
        return collection.find(filter).first();
    }

    public Order updateOrder(Order order) {
        if(order.getDeliveryUser() != null){ saveAssociation(order,order.getDeliveryUser(), "orderDeliverUser");}
        Bson filter = eq("_id", order.getObjectId());
        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
        collection.replaceOne(filter, order);
        return collection.find(filter).first();
    }

    public <T extends PersistentObject> List<T> getObjectsAssociatedWith(
            ObjectId objectId, Class<T> objectClass, String association, String destCollection) {
        AggregateIterable<T> iterable =
                this.getDb()
                        .getCollection(association, objectClass)
                        .aggregate(
                                Arrays.asList(
                                        match(eq("destination", objectId)),
                                        lookup(destCollection, "source", "_id", "_matches"),
                                        unwind("$_matches"),
                                        replaceRoot("$_matches")));
        Stream<T> stream =
                StreamSupport.stream(Spliterators.spliteratorUnknownSize(iterable.iterator(), 0), false);
        return stream.collect(Collectors.toList());
    }
    
    public List<Order> findOrdersMadeByUser(String username){
    	List<Order> orders = new ArrayList<Order>();
        MongoCollection<Association> orderUser = getDb().getCollection("orderClientUser", Association.class);
        Iterator<Association> orderIterable =  orderUser.find(eq("destination", this.findUserByUsername(username).getObjectId())).iterator();
        while(orderIterable.hasNext()) {
        	Order o = this.findOrderById(orderIterable.next().getSource());
        	orders.add(o);      	
        }
        return orders;
    }

    public List<Supplier> findTopSuppliers( int n){
        MongoCollection<Supplier> collection = getDb().getCollection("orders", Supplier.class);
        AggregateIterable<Supplier> aggregate = collection.aggregate(Arrays.asList(
                match(eq("orderState.status", "Sended")),
                unwind("$orderLines"),
                group("$orderLines.product.supplier._id", Accumulators.sum("total", "$orderLines.amount"),
                        Accumulators.first("suppliers", "$orderLines.product.supplier")),
                sort(Sorts.descending("total")),
                limit(n),
                replaceRoot("$suppliers")
                ));

        List<Supplier> suppliers = new ArrayList<Supplier>();
        MongoCursor<Supplier> iterator = aggregate.iterator();
        while (iterator.hasNext()) {
            Supplier next = iterator.next();
            suppliers.add(next);
        }
        return suppliers;
    }

    public List <Order> findPendingOrders(){
    	MongoCollection<Order> orderCollection = getDb().getCollection("orders", Order.class);      
        List<Order> orders = new Vector<Order>();
        Iterator<Order> orderIterable =  orderCollection.find(eq("orderState.name", "Pending")).iterator();
        while(orderIterable.hasNext()) {
            orders.add(orderIterable.next());
        }
        return orders;
    }
    
    public List <Order>  findSentOrders(){
    	MongoCollection<Order> orderCollection = getDb().getCollection("orders", Order.class);
        List<Order> orders = new Vector<Order>();
        Iterator<Order> orderIterable =  orderCollection.find(eq("orderState.name", "Sended")).iterator();
        while(orderIterable.hasNext()) {
            orders.add(orderIterable.next());
        }
        return orders;      
    }
     
    public List <Order> findDeliveredOrdersInPeriod(Date startDate, Date endDate){
    	MongoCollection<Order> orderCollection = getDb().getCollection("orders", Order.class);
        List<Order> orders = new Vector<Order>();
        List<Bson> filtersFecha = new Vector<Bson>();
    	filtersFecha.add(Filters.gte("orderState.startDate", startDate));
    	filtersFecha.add(Filters.lte("orderState.startDate", endDate));
    	filtersFecha.add(Filters.eq("orderState.name", "Delivered"));
        Iterator<Order> orderIterable =  orderCollection.find(Filters.and(filtersFecha)).iterator();
        while(orderIterable.hasNext()) {
            orders.add(orderIterable.next());
        }
        return orders;
    }

    public List <Order> findDeliveredOrdersForUser(String username){
    	User u = this.findUserByUsername(username);
    	List<Order> orders = new Vector<Order>();
    	return this.getDb().getCollection("orders", Order.class).aggregate(
    			Arrays.asList(
    				  match(eq("orderState.name", "Delivered")),
    				  lookup("orders","_id","_id","order"),
    				  unwind("$order"),replaceRoot("$order"),
				      lookup("orderClientUser","_id","source","oc"), 
				      unwind("$oc"),        				    
    				  lookup("users","oc.destination","_id","client"),
    				  match(eq("oc.destination",u.getObjectId())),
    				  unwind("$client")
    				  ))
    		  .into(orders);  	
    }
    
    public Product findBestsSellingProduct() {
       return this.getDb().getCollection("orders", Product.class).aggregate(Arrays.asList(
                unwind("$orderLines"),
                group("$orderLines.product._id", Accumulators.sum("total", "$orderLines.amount"),
                        Accumulators.first("products", "$orderLines.product")),
                sort(Sorts.descending("total")),
                replaceRoot("$products")
        )).first();
    }

    public FindIterable<Product> findProductsOnePrice(){
        MongoCollection<Product> products = getDb().getCollection("products", Product.class);
        return products.find(Filters.and(Filters.size("prices", 1)));

    }

    public List <Product> findSoldProductsOn(Date day){
    	 List<Product> products = new Vector<Product>(); 	 
		 return this.getDb().getCollection("products", Product.class).aggregate(Arrays.asList(lookup("orders", "_id", "orderLines.product._id", "orders"), match(eq("orders.dateOfOrder", day)))).into(products);
    } 

    public List <Order> findOrderNearPlazaMoreno(){
    	MongoCollection<Order> orderCollection = getDb().getCollection("orders", Order.class);
    	List<Order> orders = new Vector<Order>();
    	orderCollection.createIndex(Indexes.geo2dsphere("position"));
    	Point refPoint = new Point(new Position(-34.921236,-57.954571));
    	Iterator<Order> orderIterable =  orderCollection.find (Filters.near("position", refPoint, 400.0, 0.0)).iterator();
    	while(orderIterable.hasNext()) {
    		orders.add(orderIterable.next());     	
    	}  
    	return orders;
    }

    public Optional getProductMaxWeigth() {
        MongoCollection<Product> product = this.getDb().getCollection("products", Product.class);
        return Optional.ofNullable(product.find().sort(Sorts.descending("weight")).first());
    }
}