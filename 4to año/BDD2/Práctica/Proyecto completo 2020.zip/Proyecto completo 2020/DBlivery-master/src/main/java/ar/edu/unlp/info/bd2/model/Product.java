package ar.edu.unlp.info.bd2.model;

import javax.persistence.*;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@Entity
@Table(name = "Product")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private Float weight;
	private Date date;
	private Float price;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "product_id")
	private Set<Price> prices = new HashSet<Price>();

	@ManyToOne(fetch = FetchType.LAZY)
	private Supplier supplier = new Supplier();

	public Product() {}

	public Product(String name, Float weight, Supplier supplier, Float price) {
		setName(name);
		setWeight(weight);
		setSupplier(supplier);
		Calendar cal = Calendar.getInstance();
		Date startDate = cal.getTime();
		updateProductPrice(price, startDate);
	}

	public Product(String name, Float weight, Supplier supplier, Float price, Date date) {
		setName(name);
		setWeight(weight);
		setSupplier(supplier);
		Calendar cal = Calendar.getInstance();
		Date startDate = cal.getTime();
		updateProductPrice(price, date);
		setDate(date);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Float getWeight() {
		return weight;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}

	public Long getId() {
		return id;
	}

	public void setId(long productId) {
		this.id = productId;
	}

	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public Set<Price> getPrices() {
		return prices;
	}

	public void setPrices(Price price) {
		prices.add(price);
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Float getPrice() {
		return this.price;
	}

	public Product updateProductPrice(Float price, Date startDate) {
		Price newPrice = new Price(price, startDate);
		setPrices(newPrice);
		setPrice(price);
		return this;
	}
}