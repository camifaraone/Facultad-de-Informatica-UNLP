package ar.edu.unlp.info.bd2.model;

import ar.edu.unlp.info.bd2.repositories.DBliveryException;

import javax.persistence.*;
import java.util.Date;

@Entity(name = "OrderState")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "state_type", discriminatorType = DiscriminatorType.STRING)
public abstract class OrderState  {
    @Id
    @GeneratedValue
    protected Long id;
    protected String name;
    protected Date startDate;

    protected abstract void setName(String name);

    protected abstract String getName();

    protected abstract void setId(Long id);

    protected abstract Long getId();

    public abstract String getStatus();

    protected abstract Boolean canSended();

    protected abstract Boolean canDelivered();

    protected abstract Boolean canCancel();

    protected abstract Boolean canFinish();

    protected abstract Date getStartDate();

    protected abstract void setStartDate(Date startDate);

	protected abstract void changeDelivered(Order order, Date date) throws DBliveryException;

    protected abstract void changeDelivered(Order order) throws DBliveryException;

    protected abstract void changeCanceled(Order order, Date date) throws DBliveryException;

    protected abstract void changeCanceled(Order order) throws DBliveryException;

    protected abstract void changeSended(Order order, Date date) throws DBliveryException;

    protected abstract void changeSended(Order order) throws DBliveryException;

    public abstract void changePending(Order order) throws DBliveryException;

    public abstract void changePending(Order order, Date date) throws DBliveryException;
}
