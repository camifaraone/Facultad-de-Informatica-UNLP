package ar.edu.unlp.info.bd2.services;

import ar.edu.unlp.info.bd2.repositories.DBliveryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import ar.edu.unlp.info.bd2.model.*;
import ar.edu.unlp.info.bd2.repositories.DBliveryException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

public class DBliveryServiceImpl implements DBliveryService {

	@Autowired
	private DBliveryRepository repository;

	public DBliveryServiceImpl(DBliveryRepository repository) {
		this.repository = repository;
	}

	// User
	@Transactional
	public User createUser(String email, String password, String username, String name, Date dateOfBirth){
		User user = new User(email, password, username, name, dateOfBirth);
		return this.repository.persistUser(user);
	}
	
	@Transactional
	public Optional<User> getUserById(Long id) {
		return Optional.ofNullable(this.repository.findUserById(id));
	}
	
	@Transactional
	public Optional<User> getUserByEmail(String email) {
		return Optional.ofNullable(this.repository.findUserByEmail(email));
	}

	@Transactional
	public Optional<User> getUserByUsername(String username) {
		return Optional.ofNullable(this.repository.findUserByUsername(username));
	}

	// Product

	@Transactional
	public Product createProduct(String name, Float price, Float weight, Supplier supplier){
		Product product = new Product(name, weight, supplier, price);
		return this.repository.persistProduct(product);
	}

	@Transactional
	public Product createProduct(String name, Float price, Float weight, Supplier supplier, Date date){
		Product product = new Product(name, weight, supplier, price, date);
		return this.repository.persistProduct(product);
	}

	@Transactional
	public Optional<Product> getProductById(Long id) {
		return Optional.ofNullable(this.repository.findProductById(id));
	}

	@Transactional
	public List <Product> getProductByName(String name) {
		return this.repository.findProductByName(name);
	}

	@Transactional
	public Product updateProductPrice(Long id, Float price, Date startDate) throws DBliveryException {
		try {
			Product product = this.repository.findProductById(id);
			if (product == null) {
				throw new DBliveryException("Product not found");
			}
			product.updateProductPrice(price, startDate);
			return this.repository.updateProductPrice(product);		
		} catch (DBliveryException e) {
			return null;
		}
	}

	// Supplier
	@Transactional
	public Supplier createSupplier(String name, String cuil, String address, Float coordX, Float coordY){
		Supplier supplier = new Supplier(name, cuil, address, coordX,coordY);
		return repository.persistSupplier(supplier);
	}

	// Order
	@Transactional
	public Order createOrder(Date dateOfOrder, String address, Float coordX, Float coordY, User client) {
		Order order = new Order(dateOfOrder, address, coordX, coordY, client);
		return this.repository.persistOrder(order);
	}

	@Transactional
	public Order cancelOrder(Long orderId) throws DBliveryException {
		Order order = repository.findOrderById(orderId);
		if (order == null) throw new DBliveryException("Order not found");
		order.cancel();
		return this.repository.updateOrder(order);
	}

	@Transactional
	public Order cancelOrder(Long orderId, Date date) throws DBliveryException {
		Order order = repository.findOrderById(orderId);
		if (order == null) throw new DBliveryException("Order not found");
		order.cancel(date);
		return this.repository.updateOrder(order);
	}

	@Transactional
	public Optional<Order> getOrderById(Long id) {
		return Optional.ofNullable(this.repository.findOrderById(id));
	}

	@Transactional
	public Order addProduct(Long orderId, Long quantity, Product product) throws DBliveryException {
		try {
			Order order = this.repository.findOrderById(orderId);
			if (order == null) throw new DBliveryException("Order not found");
			order.addOrderLine(quantity, product);
			return this.repository.updateOrder(order);
		} catch (DBliveryException e) {	return null; }
	}

	@Transactional
	public Order deliverOrder(Long id, User deliveryUser) throws DBliveryException {
		Order order = this.repository.findOrderById(id);
		if (order == null) throw new DBliveryException("Order not found");
		order.deliver(deliveryUser);
		return this.repository.updateOrder(order);
	}

	@Transactional
	public Order deliverOrder(Long id, User deliveryUser, Date date) throws DBliveryException {
		Order order = this.repository.findOrderById(id);
		if (order == null) throw new DBliveryException("Order not found");
		order.deliver(deliveryUser,date);
		return this.repository.updateOrder(order);
	}

	@Transactional
	public Order finishOrder(Long id) throws DBliveryException {
		Order order = this.repository.findOrderById(id);
		if (order == null) throw new DBliveryException("Order not found");
		order.finish();
		return this.repository.updateOrder(order);
	}

	@Transactional
	public Order finishOrder(Long id, Date date) throws DBliveryException {
		Order order = repository.findOrderById(id);
		if (order == null) throw new DBliveryException("Order not found");
		order.finish(date);
		return this.repository.updateOrder(order);
	}

	@Transactional
	public boolean canCancel(Long id) throws DBliveryException {
		Order order = repository.findOrderById(id);
		if (order == null) throw new DBliveryException( "Order not found");
		return order.canCancel();
	}

	@Transactional
	public boolean canFinish(Long id) throws DBliveryException {
		try {
			Order order = this.repository.findOrderById(id);
			if (order == null) throw new DBliveryException("Order not found");
			return order.canFinish();
		} catch (DBliveryException e) {
			return false;
		}
	}

	@Transactional
	public boolean canDeliver(Long id) throws DBliveryException {
		try {
			Order order = repository.findOrderById(id);
			if (order == null) throw new DBliveryException("Order not found");
			return order.canDeliver();
		} catch (DBliveryException e) {
			return false;
		}
	}

	@Transactional
	public OrderState getActualStatus(Long id) {
		Order order = this.repository.findOrderById(id);
		return order.getOrderState();
	}

	@Transactional
	public List<Order> getAllOrdersMadeByUser(String username) {
		return repository.getAllOrdersMadeByUser(username);
	}

	
	@Transactional
    public List<User> getUsersSpendingMoreThan(Float amount){
        return repository.getUsersSpendingMoreThan(amount);

    }

	@Transactional
	public List<Supplier> getTopNSuppliersInSentOrders(int n) {
		return repository.getTopNSuppliersInSentOrders(n);
	}

	@Transactional
	public List<Product> getTop10MoreExpensiveProducts() {
		return repository.getTop10MoreExpensiveProducts();
	}

	@Transactional
	public List<User> getTop6UsersMoreOrders() {
		return repository.getTop6UsersMoreOrders();
	}

	@Transactional
	public List<Order> getCancelledOrdersInPeriod(Date startDate, Date endDate) {
		return repository.getCancelledOrdersInPeriod(startDate, endDate);
	}

	@Transactional
	public List<Order> getPendingOrders() {
		return repository.getPendingOrders();
	}

	@Transactional
	public List<Order> getSentOrders() {
		return repository.getSentOrders();
	}

	@Transactional
	public List<Order> getDeliveredOrdersInPeriod(Date startDate, Date endDate) {
		return repository.getDeliveredOrdersInPeriod(startDate, endDate);
	}

	@Transactional
	public List<Order> getDeliveredOrdersForUser(String username) {
		return repository.getDeliveredOrdersForUser(username);
	}

	@Transactional
	public List<Order> getSentMoreOneHour() {
		return repository.getSentMoreOneHour();
	}

	@Transactional
	public List<Order> getDeliveredOrdersSameDay() {
		return repository.getDeliveredOrdersSameDay();
	}

	@Transactional
	public List<User> get5LessDeliveryUsers() {
		return repository.get5LessDeliveryUsers();
	}
	

	@Transactional
	public Product getBestSellingProduct() {
		return repository.getBestSellingProduct();
	}

	@Transactional
	public List<Product> getProductsOnePrice() {
		return repository.getProductsOnePrice();
	}

	@Transactional
	public List<Product> getProductIncreaseMoreThan100() {
		return repository.getProductIncreaseMoreThan100();
		
	}

	@Transactional
	public Supplier getSupplierLessExpensiveProduct() {
		return repository.getSupplierLessExpensiveProduct();
	}

	@Transactional
	public List<Supplier> getSuppliersDoNotSellOn(Date day) {
		return repository.getSuppliersDoNotSellOn(day);
	}

	@Transactional
	public List<Product> getSoldProductsOn(Date day) {
		return repository.getSoldProductsOn(day);
	}

	@Transactional
	public List<Order> getOrdersCompleteMorethanOneDay() {
		return repository.getOrdersCompleteMorethanOneDay();
	}

	@Transactional
	public List<Object[]> getProductsWithPriceAt(Date day) {
		return repository.getProductsWithPriceAt(day);
	}

	@Transactional
	public List<Product> getProductsNotSold() {
		
		return repository.getProductsNotSold();
	}

	@Transactional
	public List<Order> getOrderWithMoreQuantityOfProducts(Date day) {
		return repository.getOrderWithMoreQuantityOfProducts(day);
	}
}
