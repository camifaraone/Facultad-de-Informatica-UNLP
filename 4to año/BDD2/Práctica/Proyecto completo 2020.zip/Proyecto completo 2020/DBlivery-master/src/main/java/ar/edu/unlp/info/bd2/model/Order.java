package ar.edu.unlp.info.bd2.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import ar.edu.unlp.info.bd2.repositories.DBliveryException;

@Entity
@Table(name = "Orden")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name="order_id")
	private Set<OrderLine> orderLines = new HashSet<OrderLine>();

    @OneToOne(fetch = FetchType.LAZY)
	private User deliveryUser;

	@ManyToOne(fetch = FetchType.LAZY)
	private User client;

	@OneToOne(fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	@JoinColumn(name = "idOrderState")
	private OrderState orderState;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "order_id")
	private Set<OrderState> states = new HashSet<OrderState>();

	private String address;
	private Date dateOfOrder;
	private Float coordX;
	private Float coordY;
	private Float amount;

	public Order() {
	}

	public Order(Date dateOfOrder, String address, Float coordX,  Float coordY, User client) {
		setDateOfOrder(dateOfOrder);
		setClient(client);
		setAddress(address);
		setCoordX(coordX);
		setCoordY(coordY);
		Pending pending = new Pending(dateOfOrder);
		setOrderState(pending);
		setStates(pending);
	}

	public Order getId(Long id) {
		return this;
	}

	public long getId() {
		return id;
	}

	public void setId(Long orderId) {
		this.id = orderId;
	}

	public OrderState getOrderState() {
		return orderState;
	}

	public void setOrderState(OrderState orderState) {
		this.orderState = orderState;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

    public Set<OrderState> getStatus() {
		return getStates();
	}

	public void setStatus(OrderState orderState) {
		setOrderState(orderState);
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDateOfOrder() {
		return dateOfOrder;
	}

	public void setDateOfOrder(Date dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}

    public Float getCoordX() {
		return coordX;
	}

    public void setCoordX(Float coordX) {
		this.coordX = coordX;
	}
    
    public Float getCoordY() {
		return coordY;
	}

    public void setCoordY(Float coordY) {
		this.coordY = coordY;
	}

    public Set<OrderLine> getOrderLines() {
		return orderLines;
	}

	public User getDeliveryUser() {
		return deliveryUser;
	}

	public void setDeliveryUser(User deliveryUser) {
		this.deliveryUser = deliveryUser;
	}

	public void setOrderLines(OrderLine orderLine) {
		this.orderLines.add(orderLine);
	}

	public Set<Product> getProducts() {
		Set<Product> products = new HashSet<Product>();
		Iterator orderLineIterator = this.orderLines.iterator();
		while (orderLineIterator.hasNext()){
			OrderLine anOrderLine = (OrderLine) orderLineIterator.next();
			products.add(anOrderLine.getProduct());
		}
		return products;
	}

	public Set<OrderState> getStates() {
		return states;
	}

	public void setStates(OrderState state) {
		this.states.add(state);
	}

	public void addOrderLine(long amount, Product product) {
		OrderLine newOrderLine = new OrderLine(amount, product);
		setOrderLines(newOrderLine);
	}

	public Boolean canDeliver() throws DBliveryException{
		if (this.getOrderLines().isEmpty()) throw new DBliveryException("Order can not delivered");
		return orderState.canDelivered();
	}

	public Boolean canFinish() {
		return orderState.canFinish();
	}

	public Boolean canCancel() {
		return orderState.canCancel();
	}

	public Boolean canSended() {
		return orderState.canSended();
	}

	public Order changeStatePending() throws DBliveryException {
		orderState.changePending(this);
		this.updateAmount();
		return this;
	}

	public Order changeStatePending(Date date) throws DBliveryException {
		this.orderState.changePending(this, date);
		this.updateAmount();
		return this;
	}

	
	public Order changeStateDelivered() throws DBliveryException {
		this.orderState.changeDelivered(this);
		this.updateAmount();
		return this;
	}
	
	public Order changeStateDelivered(Date date) throws DBliveryException {
		this.orderState.changeDelivered(this, date);
		this.updateAmount();
		return this;
	}

	public Order changeStateCanceled() throws DBliveryException {
		this.orderState.changeCanceled(this);
		this.updateAmount();
		return this;
	}

	public Order changeStateCanceled(Date date) throws DBliveryException {
		this.orderState.changeCanceled(this, date);
		this.updateAmount();
		return this;
	}

	public Order changeStateSended() throws DBliveryException {
		this.orderState.changeSended(this);
		this.updateAmount();
		return this;
	}

	public Order changeStateSended(Date date) throws DBliveryException {
		this.orderState.changeSended(this, date);
		this.updateAmount();
		return this;
	}

	public Order deliverOrder(User deliveryUser) throws DBliveryException {
		this.setDeliveryUser(deliveryUser);
		this.orderState.changeSended(this);
		return this;
	}

	public Order deliverOrder(User deliveryUser, Date date) throws DBliveryException {
		this.setDeliveryUser(deliveryUser);
		this.orderState.changeSended(this, date);
		return this;
	}
	

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public void updateAmount() {
		Float totalAmount = (float) 0;
		Iterator orderLineIterator = this.getOrderLines().iterator();
		while (orderLineIterator.hasNext()){
			OrderLine orderLine = (OrderLine) orderLineIterator.next();
			Set<Price> prices = orderLine.getProduct().getPrices();
			Iterator  i = prices.iterator();
			Price priOk = null;
			while (i.hasNext()){
				Price pri = (Price) i.next();
				if(this.orderState.getStartDate()!=null)
				{	
					if((priOk==null  || (pri.getStartDate().after(priOk.getStartDate()))) &&  pri.getStartDate().before(this.getOrderState().getStartDate()))
						priOk = pri;
				}
				else
					priOk = pri;
			}
			float price = priOk.getValue();
			float amount = (float)orderLine.getAmount();

			totalAmount += amount*price;
		}
		this.setAmount(totalAmount);
	}
	
	public void finish() throws DBliveryException {
		this.changeStateDelivered();
	}
	
	public void finish(Date date) throws DBliveryException {
		this.changeStateDelivered(date);
	}

	public void deliver(User deliveryUser) throws DBliveryException {
		if (this.getOrderLines().isEmpty()) throw new DBliveryException("Order can not delivered");
		this.setDeliveryUser(deliveryUser);
		this.changeStateSended();
	}

	public void deliver(User deliveryUser, Date date) throws DBliveryException {
		if (this.getOrderLines().isEmpty()) throw new DBliveryException("Order can not delivered");
		this.setDeliveryUser(deliveryUser);
		this.changeStateSended(date);
	}

	public void cancel() throws DBliveryException {
		this.changeStateCanceled();
	}

	public void cancel(Date date) throws DBliveryException {
		this.changeStateCanceled(date);
	}	
	
	public void sended() throws DBliveryException {
		this.changeStateSended();
	}
	
	public void sended(Date date) throws DBliveryException {
		this.changeStateSended(date);
	}
}
