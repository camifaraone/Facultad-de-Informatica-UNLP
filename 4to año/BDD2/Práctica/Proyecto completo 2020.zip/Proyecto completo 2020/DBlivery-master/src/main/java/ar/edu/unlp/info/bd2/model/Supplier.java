package ar.edu.unlp.info.bd2.model;

import javax.persistence.*;
import java.util.*;

@Entity
@Table(name = "Supplier")
public class Supplier {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String cuil;
    private String address;
	private Float coordX;
	private Float coordY;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "supplier", cascade = CascadeType.ALL)
	private Set<Product> products = new HashSet<Product>();

	public Supplier() {	}

	public Supplier(String name, String cuil, String address, Float coordX,  Float coordY) {
		setName(name);
		setCuil(cuil);
		setAddress(address);
		setCoordX(coordX);
		setCoordY(coordY);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCuil() {
		return cuil;
	}

	public void setCuil(String cuil) {
		this.cuil = cuil;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Float getCoordX() {
		return coordX;
	}

    public void setCoordX(Float coordX) {
		this.coordX = coordX;
	}
    
    public Float getCoordY() {
		return coordY;
	}

    public void setCoordY(Float coordY) {
		this.coordY = coordY;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long supplierId) {
		this.id = supplierId;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Product product) {
		this.products.add(product);
	}

	public Set<Product> getProductByName(String name) {
		Set<Product> productsByName = new HashSet<Product>();
		Iterator productIterator = this.products.iterator();
		while (productIterator.hasNext()){
			Product aProduct = (Product) productIterator.next();
			if (aProduct.getName().contains(name)){
				productsByName.add(aProduct);
			}
		}
		return productsByName;
	}

	public Product getProductById(Long id) {
		Product productById = new Product();
		Iterator productIterator = this.products.iterator();
		while (productIterator.hasNext()){
			Product aProduct = (Product) productIterator.next();
			if (aProduct.getId() == id){
				productById = aProduct;
			}
		}
		return productById;
	}

	public Product createProduct(String name, Float weight, Float price) {
		Product newProduct = new Product(name, weight, this, price, new Date());
		setProducts(newProduct);
		return newProduct;
	}

	public Product updateProductPrice(Long id, Float price, Date startDate){
		Product aProduct = getProductById(id);
		if (aProduct.getId() == id ) {
			aProduct.updateProductPrice(price, startDate);
		}
		return aProduct;
	}
}