package ar.edu.unlp.info.bd2.repositories;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import ar.edu.unlp.info.bd2.model.Order;
import ar.edu.unlp.info.bd2.model.Product;
import ar.edu.unlp.info.bd2.model.Supplier;
import ar.edu.unlp.info.bd2.model.User;

public class DBliveryRepository {
	
	@Autowired
	private SessionFactory sessionFactory;

	public Session getSession(){
		return this.sessionFactory.getCurrentSession();
	}

	// User

	public User findUserByEmail(String email) {
		String hql = "from User where email = :email ";
		Query query = getSession().createQuery(hql);
		query.setParameter("email", email);
		List<User> users = query.getResultList();
		return !users.isEmpty() ? users.get(query.getFirstResult()) : null;
	}

	public User findUserById(Long id) {
		String hql = "from User where id = :id ";
		Query query = getSession().createQuery(hql);
		query.setParameter("id", id);
		List<User> users = query.getResultList();
		return !users.isEmpty() ? users.get(query.getFirstResult()) : null;
	}

	public User findUserByUsername(String username) {
		String hql = "from User where username = :username ";
		Query query = getSession().createQuery(hql);
		query.setParameter("username", username);
		List<User> users = query.getResultList();
		return !users.isEmpty() ? users.get(query.getFirstResult()) : null;
	}

	public User persistUser(User user){
		Long id = (Long)this.sessionFactory.getCurrentSession().save(user);
		return this.findUserById(id);
	}

	public List<User> getTop6UsersMoreOrders() {
		String hql = "SELECT c FROM Order o join o.client c GROUP BY c.id ORDER BY COUNT(o.id) DESC";
		Query query = getSession().createQuery(hql);
		query.setMaxResults(6);
		List<User> users = query.getResultList();
		return users;
	}

	public List<User> getUsersSpendingMoreThan(Float amount) {
		String stmt = "SELECT c FROM Order o join o.client c join o.orderState os WHERE o.amount > :amount";
		Query query = getSession().createQuery(stmt);
		query.setParameter("amount", amount);
		List<User> results = query.getResultList();
		return results;
	}

	public List<User> get5LessDeliveryUsers() {
		String hql = "SELECT d FROM Order o join o.deliveryUser d GROUP BY d.id ORDER BY COUNT(o.id) ASC";
		Query query = getSession().createQuery(hql);
		query.setMaxResults(5);
		List<User> users = query.getResultList();
		return users;
	}

	// Product

	public Product findProductById(Long id) {
		String hql = "from Product where id = :id ";
		Query query = getSession().createQuery(hql);
		query.setParameter("id", id);
		List<Product> products = query.getResultList();
		return !products.isEmpty() ? products.get(query.getFirstResult()) : null;
	}

	public Product persistProduct(Product product) {
		Long id = (Long)getSession().save(product);
		return this.findProductById(id);

	}

	public List <Product> findProductByName(String name) {
		String hql = "from Product where name LIKE CONCAT('%',:name, '%')";
		Query query = getSession().createQuery(hql);
		query.setParameter("name", name);
		List<Product> products = query.getResultList();
		return !products.isEmpty() ? products : null;
	}

	public Product updateProductPrice(Product product) {
		getSession().save(product);
		return product;
	}

	public List<Product> getTop10MoreExpensiveProducts() {
		String hql = "SELECT p FROM Product p ORDER BY p.price DESC";
		Query query = getSession().createQuery(hql);
		query.setMaxResults(9);
		List<Product> products = query.getResultList();
		return products;
	}

	public List<Product> getSoldProductsOn(Date day) {
		String hql = "SELECT p FROM Order o join o.orderLines ol join ol.product p WHERE o.dateOfOrder = :day";
		Query query = getSession().createQuery(hql);
		query.setParameter("day", day);
		List<Product> results = query.getResultList();
		return results;
	}

	public List<Product> getProductsOnePrice(){
		String hql = "SELECT p FROM Product p join p.prices group by p HAVING COUNT(p) =1";
		Query query = getSession().createQuery(hql);
		List<Product> results = query.getResultList();
		return results;
	}

	public Product getBestSellingProduct() {
		String hql = "SELECT p FROM Order o join o.orderLines ol join ol.product p group by p order by COUNT(p) DESC";
		Query query = getSession().createQuery(hql);
		query.setMaxResults(1);
		List<Product> results = query.getResultList();
		return results.get(0);
	}

	public List<Product> getProductIncreaseMoreThan100() {
		String hql = "SELECT p FROM Product p join p.prices pri with pri.id IN(SELECT MIN(pri.id) FROM Product p join p.prices pri group by p) WHERE p.price > pri.value*2 ";
		Query query = getSession().createQuery(hql);
		List<Product> results = query.getResultList();
		return results;
	}

	public List<Product> getProductsNotSold() {
		String hql = "SELECT p FROM Product p WHERE p.id NOT IN (SELECT p FROM Order o join o.orderLines ol join ol.product p)";
		Query query = getSession().createQuery(hql);
		List<Product> results = query.getResultList();
		return results;
	}

	// Order

	public Order findOrderById(Long id){
		String hql = "from Order where id = :id ";
		Query query = getSession().createQuery(hql);
		query.setParameter("id", id);
		List<Order> orders = query.getResultList();
		return !orders.isEmpty() ? orders.get(query.getFirstResult()) : null;
	}

	public Order persistOrder(Order order){
		Long id = (Long)getSession().save(order);
		return this.findOrderById(id);
	}

	public Order updateOrder(Order order) {
		getSession().save(order);
		return this.findOrderById(order.getId());
	}

	public List<Order> getAllOrdersMadeByUser(String username){
		String hql = "SELECT o FROM Order o join o.client c WHERE c.username = :username";
		Query query = getSession().createQuery(hql);
		query.setParameter("username", username);
		List<Order> orders = query.getResultList();
		return orders;
	}

	public List<Order> getCancelledOrdersInPeriod(Date startDate, Date endDate) {
		String hql = "SELECT o FROM Order o join o.orderState os WHERE os.name = 'Cancelled' AND os.startDate >= :start AND os.startDate <= :end";
		Query query = getSession().createQuery(hql);
		query.setParameter("start", startDate);
		query.setParameter("end", endDate);
		List<Order> orders = query.getResultList();
		return orders;
	}

	public List<Order> getPendingOrders() {
		String hql = "SELECT o FROM Order o join o.orderState os WHERE os.name = 'Pending'";
		Query query = getSession().createQuery(hql);
		List<Order> orders = query.getResultList();
		return orders;
	}

	public List<Order> getSentOrders() {
		String hql = "SELECT o FROM Order o join o.orderState os WHERE os.name = 'Sended'";
		Query query = getSession().createQuery(hql);
		List<Order> orders = query.getResultList();
		return orders;
	}

	public List<Order> getDeliveredOrdersInPeriod(Date startDate, Date endDate)	{
		String hql = "SELECT o FROM Order o join o.orderState os WHERE os.name = 'Delivered' AND os.startDate >= :start AND os.startDate <= :end";
		Query query = getSession().createQuery(hql);
		query.setParameter("start", startDate);
		query.setParameter("end", endDate);
		List<Order> orders = query.getResultList();
		return orders;
	}

	public List<Order> getOrdersCompleteMorethanOneDay() {
		String hql = "SELECT o FROM Order o join o.orderState os WHERE os.name = 'Delivered' AND os.startDate > o.dateOfOrder";
		Query query = getSession().createQuery(hql);
		List<Order> results = query.getResultList();
		return  results;
	}

	public List<Order> getDeliveredOrdersForUser(String username) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -10);
		Date date = cal.getTime();
		String hql = "SELECT o FROM Order o join o.client c join o.orderState os with os.name = 'Delivered' WHERE c.username = :username";
		Query query = getSession().createQuery(hql);
		query.setParameter("username", username);
		List<Order> results = query.getResultList();
		return  results;
	}

	public List<Order> getDeliveredOrdersSameDay() {
		String hql = "SELECT o FROM Order o join o.orderState os WHERE os.name = 'Delivered' AND (DAY(o.dateOfOrder) = DAY(os.startDate))";
		Query query = getSession().createQuery(hql);
		List<Order> results = query.getResultList();
		return  results;
	}

	public List<Order> getSentMoreOneHour() {
		String hql = "SELECT o FROM Order o join o.states osP with osP.name='Pending' join o.states osS with "
				+ "osS.name='Sended' WHERE TIMEDIFF(osS.startDate, osP.startDate) > 1";
		Query query = getSession().createQuery(hql);
		List<Order> results = query.getResultList();

		return  results;
	}

	public List<Order> getOrderWithMoreQuantityOfProducts(Date day) {
		String aux = "SELECT sum(ol2.amount) FROM Order o2 join o2.orderLines ol2 WHERE o2.dateOfOrder = :day group by o2.id order by sum(ol2.amount) DESC ";
		Query queryAux = getSession().createQuery(aux);
		queryAux.setParameter("day", day);
		queryAux.setMaxResults(1);
		List<Integer> max = queryAux.getResultList();
		String hql = "SELECT o FROM Order o join o.orderLines ol WHERE o.dateOfOrder = :day group by o.id HAVING sum(ol.amount) = :max ";
		Query query = getSession().createQuery(hql);
		query.setParameter("day", day);
		query.setParameter("max", max.get(0));
		List<Order> orders = query.getResultList();
		return orders;
	}

	// Supplier

	public Supplier findSupplierById(Long id) {
		String hql = "from Supplier where id = :id ";
		Query query = getSession().createQuery(hql);
		query.setParameter("id", id);
		List<Supplier> suppliers = query.getResultList();
		return !suppliers.isEmpty() ? suppliers.get(query.getFirstResult()) : null;
	}

	public Supplier persistSupplier(Supplier supplier) {
        Long id = (Long)getSession().save(supplier);
        return this.findSupplierById(id);
    }

	public List<Supplier> getSuppliersDoNotSellOn(Date day) {
		String hql = "SELECT s FROM Supplier s WHERE s.id NOT IN (SELECT s FROM Order o join o.orderLines ol join ol.product p join p.supplier s WHERE o.dateOfOrder = :day)";
		Query query = getSession().createQuery(hql);
		query.setParameter("day", day);
		List<Supplier> results = query.getResultList();
		return  results;
	}

	public Supplier getSupplierLessExpensiveProduct() {
		String hql = "SELECT s FROM Product p join p.supplier s join p.prices pri order by pri.value ASC";
		Query query = getSession().createQuery(hql);
		query.setMaxResults(1);
		List<Supplier> suppliers = query.getResultList();
		return suppliers.get(0);
	}

	public List<Supplier> getTopNSuppliersInSentOrders(int n){
		String hql = "SELECT s FROM Order o join o.orderState os with os.name='Sended' join o.orderLines ol join ol.product p join p.supplier s group by s order by COUNT(DISTINCT p) DESC, s.name DESC";
		Query query = getSession().createQuery(hql);
		query.setMaxResults(n);
		List<Supplier> suppliers = query.getResultList();
		return suppliers;
	}

	public List<Object[]> getProductsWithPriceAt(Date day) {
        String hql = "SELECT p, pri.value FROM Product p join p.prices pri with pri.id IN(SELECT MAX(pri.id) FROM Product p join p.prices pri where pri.startDate < :day group by p)";
        Query query = getSession().createQuery(hql);
        query.setParameter("day", day);
        List<Object[]> results = query.getResultList();
        return results;	
	}
}
