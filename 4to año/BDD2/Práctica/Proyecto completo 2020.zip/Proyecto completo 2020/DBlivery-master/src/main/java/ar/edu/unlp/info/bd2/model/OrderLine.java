package ar.edu.unlp.info.bd2.model;

import javax.persistence.*;

@Entity
@Table(name = "OrderLine")
public class OrderLine {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@OneToOne(fetch = FetchType.LAZY)
	private Product product;

	private Long amount;

	public OrderLine() {	}

	public OrderLine(Long amount, Product product) {
		setProduct(product);
		setAmount(amount);
	}

	public Long getAmount() {
		 return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long orderLineId) {
		this.id = orderLineId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}
