package ar.edu.unlp.info.bd2.model;

import ar.edu.unlp.info.bd2.repositories.DBliveryException;

import javax.persistence.OneToMany;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class DBlivery {
    @OneToMany
    private Set<User> users = new HashSet<User>();

    @OneToMany
    private Set<Order> orders = new HashSet<Order>();

    @OneToMany
    private Set<Product> products = new HashSet<Product>();

    @OneToMany
    private Set<Supplier> suppliers = new HashSet<Supplier>();

    DBlivery(){}

    private Set<User> getUsers() {
        return users;
    }

    private void setUsers(User user) {
        this.users.add(user);
    }

    private Set<Order> getOrders() {
        return orders;
    }

    private void setOrders(Order order) {
        this.orders.add(order);
    }

    private Set<Product> getProducts() {
        return products;
    }

    private void setProducts(Product product) {
        this.products.add(product);
    }

    private Set<Supplier> getSuppliers() {
        return suppliers;
    }

    private void setSuppliers(Supplier supplier) {
        this.suppliers.add(supplier);
    }

    public User getUserById(Long id){
        User userById = new User();
        Iterator userIterator = this.users.iterator();
        while (userIterator.hasNext()){
            User aUser = (User) userIterator.next();
            if (aUser.getId() == id){
                userById = aUser;
            }
        }
        return userById;
    }

    public User getUserByEmail(String email ){
        User userByEmail = new User();
        Iterator userIterator = this.users.iterator();
        while (userIterator.hasNext()){
            User aUser = (User) userIterator.next();
            if (aUser.getEmail() == email){
                userByEmail = aUser;
            }
        }
        return userByEmail;
    }

    public User getUserByUsername(String username){
        User userByUsername = new User();
        Iterator userIterator = this.users.iterator();
        while (userIterator.hasNext()){
            User aUser = (User) userIterator.next();
            if (aUser.getUsername() == username){
                userByUsername = aUser;
            }
        }
        return userByUsername;
    }

    public User createUser(String email, String password, String username, String name, Date dateOfBirth){
        User newUser = new User(email, password, username, name, dateOfBirth);
        setUsers(newUser);
        return newUser;
    }

    public Product createProduct(String name, Float weight, Supplier supplier, Float price){
        Product newProduct = supplier.createProduct(name, weight, price);
        setProducts(newProduct);
        return newProduct;
    }

    public Supplier createSupplier(String name, String cuil, String address, Float coordX, Float coordY){
        Supplier newSupplier = new Supplier(name, cuil, address, coordX,  coordY);
        setSuppliers(newSupplier);
        return newSupplier;
    }

    public Order createOrder(Date dateOfOrder, String address, Float coordX, Float coordY, User client){
        Order newOrder = client.createOrder(dateOfOrder, address, coordX, coordY);
        setOrders(newOrder);
        return newOrder;
    }

    public Set<Product> getProductByName(String name) {
        Set<Product> productsByName = new HashSet<Product>();
        Iterator productIterator = this.products.iterator();
        while (productIterator.hasNext()){
            Product aProduct = (Product) productIterator.next();
            if (aProduct.getName().contains(name)){
                productsByName.add(aProduct);
            }
        }
        return productsByName;
    }

    public Product getProductById(Long id) {
        Product productById = new Product();
        Iterator productIterator = this.products.iterator();
        while (productIterator.hasNext()){
            Product aProduct = (Product) productIterator.next();
            if (aProduct.getId() == id){
                productById = aProduct;
            }
        }
        return productById;
    }

    public OrderState getActualStatus(Long id){
        Order currentOrder = this.getOrderById(id);
        return currentOrder.getOrderState();
    }

    public Boolean canDeliver(Long id) throws DBliveryException{
        Order currentOrder = this.getOrderById(id);
        return currentOrder.canDeliver();
    }

    public Boolean canFinish(Long id){
        Order currentOrder = this.getOrderById(id);
        return currentOrder.canFinish();
    }

    public Boolean canCancel(Long id){
        Order currentOrder = this.getOrderById(id);
        return currentOrder.canCancel();
    }

    public Order finishOrder(Long id) throws DBliveryException{
        try {
            Order currentOrder = this.getOrderById(id);
            if (currentOrder.canFinish()){ throw new Exception("The order can't be finished"); }
            return currentOrder.changeStateDelivered(new Date());
        }
        catch (Exception e) { return null; }
    }

    public Order cancelOrder(Long id) throws DBliveryException {
        try {
            Order currentOrder = this.getOrderById(id);
            if (!currentOrder.canCancel()){ throw new Exception("The order can't be cancelled"); }
            return currentOrder.changeStateCanceled(new Date());
        }
        catch (Exception e) { return null; }

    }

    public Order deliverOrder(Long id, User deliveryUser){
        try {
            Order currentOrder = this.getOrderById(id);
            if (currentOrder.canDeliver()){ throw new Exception("The order can't be delivered"); }
            return currentOrder.deliverOrder(deliveryUser, new Date());
        }
        catch (Exception e) { return null; }
    }

    public Order addProduct(Long id, Float quantity, Product product){
        Order currentOrder = this.getOrderById(id);
        currentOrder.addOrderLine(quantity.longValue(), product);
        return currentOrder;
    }

    public Order getOrderById(Long id){
        Order orderById = new Order();
        Iterator orderIterator = this.orders.iterator();
        while (orderIterator.hasNext()){
            Order anOrder = (Order) orderIterator.next();
            if (anOrder.getId() == id){
                orderById = anOrder;
            }
        }
        return orderById;
    }
}
