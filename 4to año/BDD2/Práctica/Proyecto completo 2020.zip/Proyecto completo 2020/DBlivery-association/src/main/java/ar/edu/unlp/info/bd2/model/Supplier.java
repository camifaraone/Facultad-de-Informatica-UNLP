package ar.edu.unlp.info.bd2.model;
import ar.edu.unlp.info.bd2.mongo.PersistentObject;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.codecs.pojo.annotations.BsonIgnore;
import org.bson.types.ObjectId;
import java.util.*;

public class Supplier implements PersistentObject {
	@BsonId private ObjectId id;
	private String name;
	private String cuil;
    private String address;
	private Float coordX;
	private Float coordY;
	private Set<Product> products = new HashSet<Product>();

	public Supplier() {	}

	public Supplier(String name, String cuil, String address, Float coordX,  Float coordY) {
		setName(name);
		setCuil(cuil);
		setAddress(address);
		setCoordX(coordX);
		setCoordY(coordY);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCuil() {
		return cuil;
	}

	public void setCuil(String cuil) {
		this.cuil = cuil;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Float getCoordX() {
		return coordX;
	}

    public void setCoordX(Float coordX) {
		this.coordX = coordX;
	}
    
    public Float getCoordY() {
		return coordY;
	}

    public void setCoordY(Float coordY) {
		this.coordY = coordY;
	}

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId supplierId) {
		this.id = supplierId;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void addProducts(Product product) {
		getProducts().add(product);
	}

	public Set<Product> getProductByName(String name) {
		Set<Product> productsByName = new HashSet<Product>();
		Iterator productIterator = getProducts().iterator();
		while (productIterator.hasNext()){
			Product aProduct = (Product) productIterator.next();
			if (aProduct.getName().contains(name)){
				productsByName.add(aProduct);
			}
		}
		return productsByName;
	}

	public Product getProductById(ObjectId id) {
		Product productById = new Product();
		Iterator productIterator = getProducts().iterator();
		while (productIterator.hasNext()){
			Product aProduct = (Product) productIterator.next();
			if (aProduct.getId() == id){
				productById = aProduct;
			}
		}
		return productById;
	}

	public Product createProduct(String name, Float weight, Float price) {
		Product newProduct = new Product(name, weight, this, price, new Date());
		addProducts(newProduct);
		return newProduct;
	}

	public Product updateProductPrice(ObjectId id, Float price, Date startDate){
		Product aProduct = getProductById(id);
		if (aProduct.getId() == id ) {
			aProduct.updateProductPrice(price, startDate);
		}
		return aProduct;
	}

	@Override
	public ObjectId getObjectId() {
		return id;
	}

	@Override
	public void setObjectId(ObjectId objectId) {
		this.id=objectId;
	}
}