package ar.edu.unlp.info.bd2.model;
import ar.edu.unlp.info.bd2.mongo.PersistentObject;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.codecs.pojo.annotations.BsonIgnore;
import org.bson.types.ObjectId;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Product implements PersistentObject {
	@BsonId private ObjectId id;
	private Set<Price> prices = new HashSet<Price>();
	private Supplier supplier = new Supplier();
	private String name;
	private Float weight;
	private Date date;
	private Float price;

	public Product() {}

	public Product(String name, Float weight, Supplier supplier, Float price) {
		setName(name);
		setWeight(weight);
		setSupplier(supplier);
		Calendar cal = Calendar.getInstance();
		Date startDate = cal.getTime();
		updateProductPrice(price, startDate);
	}

	public Product(String name, Float weight, Supplier supplier, Float price, Date date) {
		setName(name);
		setWeight(weight);
		setSupplier(supplier);
		Calendar cal = Calendar.getInstance();
		Date startDate = cal.getTime();
		updateProductPrice(price, date);
		setDate(date);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Float getWeight() {
		return weight;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId productId) {
		this.id = productId;
	}

	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public Set<Price> getPrices() {
		return prices;
	}

	public void addPrices(Price price) {
		prices.add(price);
	}

	public void setPrices(Set<Price> price) {
		this.prices = price;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Float getPrice() {
		return this.price;
	}

	public Product updateProductPrice(Float price, Date startDate) {
		Price newPrice = new Price(price, startDate);
		addPrices(newPrice);
		setPrice(price);
		return this;
	}

	@Override
	public ObjectId getObjectId() {
		return id;
	}

	@Override
	public void setObjectId(ObjectId objectId) {
		this.id=objectId;
	}
}