package ar.edu.unlp.info.bd2.services;
import ar.edu.unlp.info.bd2.repositories.DBliveryMongoRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import ar.edu.unlp.info.bd2.model.*;
import ar.edu.unlp.info.bd2.repositories.DBliveryException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class DBliveryServiceImpl implements DBliveryService {

    @Autowired
    private DBliveryMongoRepository repository;
    public DBliveryServiceImpl(DBliveryMongoRepository repository) {
        this.repository = repository;
    }

    @Override
    public Product createProduct(String name, Float price, Float weight, Supplier supplier) {
        Product product = new Product(name, weight, supplier, price);
        return this.repository.saveProduct(product);
    }

    @Override
    public Product createProduct(String name, Float price, Float weight, Supplier supplier, Date date) {
        Product product = new Product(name, weight, supplier, price, date);
        return this.repository.saveProduct(product);
    }

    @Override
    public Supplier createSupplier(String name, String cuil, String address, Float coordX, Float coordY) {
        Supplier supplier = new Supplier(name, cuil, address, coordX,coordY);
        return this.repository.saveSupplier(supplier);
    }

    @Override
    public User createUser(String email, String password, String username, String name, Date dateOfBirth) {
        User user = new User(email, password, username, name, dateOfBirth);
        return this.repository.saveUser(user);
    }

    @Override
    public Product updateProductPrice(ObjectId id, Float price, Date startDate) throws DBliveryException {
        try {
            Product product = this.repository.findProductById(id);
            if (product == null) {
                throw new DBliveryException("Product not found");
            }
            product.updateProductPrice(price, startDate);
            return this.repository.updateProduct(product);
        } catch (DBliveryException e) {
            return null;
        }
    }

    @Override
    public Optional<User> getUserById(ObjectId id) {
        return Optional.ofNullable(this.repository.findUserById(id));
    }

    @Override
    public Optional<User> getUserByEmail(String email) {
        return Optional.ofNullable(this.repository.findUserByEmail(email));
    }

    @Override
    public Optional<User> getUserByUsername(String username) {
        return Optional.ofNullable(this.repository.findUserByUsername(username));
    }

    @Override
    public Optional<Order> getOrderById(ObjectId id) {
        return Optional.ofNullable(this.repository.findOrderById(id));
    }

    @Override
    public Order createOrder(Date dateOfOrder, String address, Float coordX, Float coordY, User client) {
        Order order = new Order(dateOfOrder, address, coordX, coordY, client);
        return this.repository.saveOrder(order);
    }

    @Override
    public Order addProduct(ObjectId orderId, Long quantity, Product product) throws DBliveryException {
        try {
            Order order = this.repository.findOrderById(orderId);
            if (order == null) throw new DBliveryException("Order not found");
            order.addOrderLine(quantity, product);
            return this.repository.updateOrder(order);
        } catch (DBliveryException e) {	return null; }
    }

    @Override
    public Order deliverOrder(ObjectId orderId, User deliveryUser) throws DBliveryException {
        Order order = this.repository.findOrderById(orderId);
        if (order == null) throw new DBliveryException("Order not found");
        order.deliver(deliveryUser);
        this.repository.updateOrder(order);
        return order;
    }

    @Override
    public Order deliverOrder(ObjectId orderId, User deliveryUser, Date date) throws DBliveryException {
        Order order = this.repository.findOrderById(orderId);
        if (order == null) throw new DBliveryException("Order not found");
        order.deliver(deliveryUser,date);
        return this.repository.updateOrder(order);
    }

    @Override
    public Order cancelOrder(ObjectId orderId) throws DBliveryException {
        Order order = this.repository.findOrderById(orderId);
        if (order == null) throw new DBliveryException("Order not found");
        order.cancel();
        return this.repository.updateOrder(order);
    }

    @Override
    public Order cancelOrder(ObjectId orderId, Date date) throws DBliveryException {
        Order order = repository.findOrderById(orderId);
        if (order == null) throw new DBliveryException("Order not found");
        order.cancel(date);
        return this.repository.updateOrder(order);
    }

    @Override
    public Order finishOrder(ObjectId orderId) throws DBliveryException {
        Order order = this.repository.findOrderById(orderId);
        if (order == null) throw new DBliveryException("Order not found");
        order.finish();
        return this.repository.updateOrder(order);
    }

    @Override
    public Order finishOrder(ObjectId orderId, Date date) throws DBliveryException {
        Order order = this.repository.findOrderById(orderId);
        if (order == null) throw new DBliveryException("Order not found");
        order.finish(date);
        return this.repository.updateOrder(order);
    }

    @Override
    public boolean canCancel(ObjectId orderId) throws DBliveryException {
        Order order = this.repository.findOrderById(orderId);
        if (order == null) throw new DBliveryException( "Order not found");
        return order.canCancel();
    }

    @Override
    public boolean canFinish(ObjectId id) throws DBliveryException {
        try {
            Order order = this.repository.findOrderById(id);
            if (order == null) throw new DBliveryException("Order not found");
            return order.canFinish();
        } catch (DBliveryException e) {
            return false;
        }
    }

    @Override
    public boolean canDeliver(ObjectId orderId) throws DBliveryException {
        try {
            Order order = this.repository.findOrderById(orderId);
            if (order == null) throw new DBliveryException("Order not found");
            return order.canDeliver();
        } catch (DBliveryException e) {
            return false;
        }
    }

    @Override
    public OrderState getActualStatus(ObjectId orderId) {
        Order order = this.repository.findOrderById(orderId);
        return order.getOrderState();
    }

    @Override
    public List<Product> getProductsByName(String name) {
        return (List<Product>) this.repository.getProductsByName(name);
    }

}