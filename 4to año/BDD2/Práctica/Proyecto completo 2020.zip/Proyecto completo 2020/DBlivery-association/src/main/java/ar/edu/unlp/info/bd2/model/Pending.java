package ar.edu.unlp.info.bd2.model;
import ar.edu.unlp.info.bd2.repositories.DBliveryException;
import org.bson.types.ObjectId;

import java.util.Date;

public class Pending extends OrderState{

	public Pending() {setName("Pending");}
	
    public Pending(Date date){
        setName("Pending");
        setStartDate(date);
    }

    public ObjectId getId(){
        return id;
    }

    public void setId(ObjectId id){
        this.id = id;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public Date getStartDate(){ return startDate; }

    public void setStartDate(Date date) { this.startDate = date; }

    @Override
    public ObjectId getObjectId() {
        return id;
    }

    @Override
    public void setObjectId(ObjectId objectId) {
        this.id = objectId;
    }

    public String getStatus(){
        return name;
    }

    public Boolean canSended(){
        return true;
    }

    public Boolean canDelivered(){
        return true;
    }

    public Boolean canCancel(){
        return true;
    }

    public Boolean canFinish(){
        return false;
    }

    public void changeDelivered(Order order, Date date) throws DBliveryException {
        throw new DBliveryException("Order can not delivered");
    }

    public void changeDelivered(Order order) throws DBliveryException {
        throw new DBliveryException("Order can not delivered");
    }

    public void changeCanceled(Order order, Date date){
        Canceled canceled = new Canceled(date);
        order.setOrderState(canceled);
        order.addStates(canceled);
    }

    public void changeCanceled(Order order){
        Canceled canceled = new Canceled();
        order.setOrderState(canceled);
        order.addStates(canceled);
    }

    public void changeSended(Order order, Date date){
        Sended sended = new Sended(date);
        order.setOrderState(sended);
        order.addStates(sended);
    }

    public void changeSended(Order order){
        Sended sended = new Sended();
        order.setOrderState(sended);
        order.addStates(sended);
    }

    public void changePending(Order order){
        Pending pending = new Pending();
        order.setOrderState(pending);
        order.addStates(pending);
    }

    public void changePending(Order order, Date date){
        Pending pending = new Pending(date);
        order.setOrderState(pending);
        order.addStates(pending);
    }
}
