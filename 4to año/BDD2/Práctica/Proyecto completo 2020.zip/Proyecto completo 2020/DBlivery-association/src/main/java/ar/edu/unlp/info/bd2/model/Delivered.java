package ar.edu.unlp.info.bd2.model;
import ar.edu.unlp.info.bd2.repositories.DBliveryException;
import org.bson.types.ObjectId;

import java.util.Date;

public class Delivered extends OrderState{
	
	public Delivered(){setName("Delivered");}

    public Delivered(Date date){
        setName("Delivered");
        setStartDate(date);
    }

    public ObjectId getId(){
        return id;
    }

    public void setId(ObjectId id){
        this.id = id;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public Date getStartDate(){ return startDate; }

    public void setStartDate(Date date) { this.startDate = date; }

    @Override
    public ObjectId getObjectId() {
        return id;
    }

    @Override
    public void setObjectId(ObjectId objectId) {
        this.id = objectId;
    }

    public String getStatus(){
        return name;
    }

    public Boolean canSended(){
        return false;
    }

    public Boolean canDelivered(){
        return false;
    }

    public Boolean canCancel(){
        return false;
    }

    public Boolean canFinish(){
        return true;
    }

    public void changeDelivered(Order order, Date date) throws DBliveryException {
        throw new DBliveryException("Order can not delivered");
    }

    public void changeDelivered(Order order) throws DBliveryException {
        throw new DBliveryException("Order can not delivered");
    }

    public void changeCanceled(Order order, Date date) throws DBliveryException {
        throw new DBliveryException("Order can not cancelled");
    }

    public void changeCanceled(Order order) throws DBliveryException {
        throw new DBliveryException("Order can not cancelled");
    }

    public void changeSended(Order order, Date date) throws DBliveryException {
        throw new DBliveryException("Order can not sended");
    }

    public void changeSended(Order order) throws DBliveryException {
        throw new DBliveryException("Order can not sended");
    }

    public void changePending(Order order) throws DBliveryException {
        throw new DBliveryException("Order can not pending");
    }

    public void changePending(Order order, Date date) throws DBliveryException {
        throw new DBliveryException("Order can not pending");
    }
}
