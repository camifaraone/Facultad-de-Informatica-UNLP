package ar.edu.unlp.info.bd2.model;
import ar.edu.unlp.info.bd2.mongo.PersistentObject;
import ar.edu.unlp.info.bd2.repositories.DBliveryException;
import org.bson.codecs.pojo.annotations.BsonDiscriminator;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.types.ObjectId;
import java.util.Date;

@BsonDiscriminator
public abstract class OrderState implements PersistentObject {
    @BsonId protected ObjectId id;
    protected String name;
    protected Date startDate;

    protected abstract ObjectId getId();

    protected abstract void setId(ObjectId id);

    protected abstract String getName();

    protected abstract void setName(String name);

    protected abstract Date getStartDate();

    protected abstract void setStartDate(Date startDate);

    public abstract String getStatus();

    protected abstract Boolean canSended();

    protected abstract Boolean canDelivered();

    protected abstract Boolean canCancel();

    protected abstract Boolean canFinish();

	protected abstract void changeDelivered(Order order, Date date) throws DBliveryException;

    protected abstract void changeDelivered(Order order) throws DBliveryException;

    protected abstract void changeCanceled(Order order, Date date) throws DBliveryException;

    protected abstract void changeCanceled(Order order) throws DBliveryException;

    protected abstract void changeSended(Order order, Date date) throws DBliveryException;

    protected abstract void changeSended(Order order) throws DBliveryException;

    public abstract void changePending(Order order) throws DBliveryException;

    public abstract void changePending(Order order, Date date) throws DBliveryException;
}
