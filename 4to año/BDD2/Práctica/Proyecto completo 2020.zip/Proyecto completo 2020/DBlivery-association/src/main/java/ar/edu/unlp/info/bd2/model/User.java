package ar.edu.unlp.info.bd2.model;
import ar.edu.unlp.info.bd2.mongo.PersistentObject;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.codecs.pojo.annotations.BsonIgnore;
import org.bson.types.ObjectId;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class User implements PersistentObject {
    @BsonId private ObjectId id;
    private Set<Order> orders;
    private String username;
    private String name;
    private String email;
    private String password;
    private Date dateOfBirth;

    public User() {};

    public User(String email, String password, String username, String name, Date dateOfBirth) {
        setUsername(username);
        setName(name);
        setEmail(email);
        setPassword(password);
        setDateOfBirth(dateOfBirth);
        Set<Order> orders =new HashSet<Order>();
        setOrders(orders);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId userId) {
        this.id = userId;
    }

    public Set<Order> getOrders() {
        return orders;
    }

    private void setOrders(Set<Order> orders) {
        this.orders = orders;
    }

    public void addOrder(Order order) {
        getOrders().add(order);
    }

    public Order createOrder(Date dateOfOrder, String address, Float coordX,  Float coordY) {
        Order newOrder = new Order(dateOfOrder, address, coordX,  coordY, this);
        addOrder(newOrder);
        return newOrder;
    }

    @Override
    public ObjectId getObjectId() {
        return id;
    }

    @Override
    public void setObjectId(ObjectId objectId) {
        this.id=objectId;
    }
}
