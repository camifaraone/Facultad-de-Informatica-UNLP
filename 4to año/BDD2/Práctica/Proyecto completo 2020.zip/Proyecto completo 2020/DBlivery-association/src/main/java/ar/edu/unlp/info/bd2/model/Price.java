package ar.edu.unlp.info.bd2.model;
import ar.edu.unlp.info.bd2.mongo.PersistentObject;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.types.ObjectId;

import java.util.Date;

public class Price implements PersistentObject {
	@BsonId	private ObjectId id;
	private Date startDate;
	private Float value;

	public Price() {}

	public Price(Float value, Date startDate) {
		setStartDate(startDate);
		setValue(value);
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Float getValue() {
		return value;
	}

	public void setValue(Float value) {
		this.value = value;
	}
	
	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId priceId) {
		this.id = priceId;
	}

	@Override
	public ObjectId getObjectId() {
		return id;
	}

	@Override
	public void setObjectId(ObjectId objectId) {
		this.id=objectId;
	}
}