package ar.edu.unlp.info.bd2.model;

import ar.edu.unlp.info.bd2.mongo.PersistentObject;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.types.ObjectId;

public class OrderLine implements PersistentObject {
	@BsonId private ObjectId id;
	private Product product;
	private Long amount;

	public OrderLine() {	}

	public OrderLine(Long amount, Product product) {
		setProduct(product);
		setAmount(amount);
	}

	public Long getAmount() {
		 return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId orderLineId) {
		this.id = orderLineId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public ObjectId getObjectId() {
		return id;
	}

	@Override
	public void setObjectId(ObjectId objectId) {
		this.id=objectId;
	}
}
