package ar.edu.unlp.info.bd2.repositories;

import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.regex;

import ar.edu.unlp.info.bd2.model.*;
import ar.edu.unlp.info.bd2.mongo.*;
import com.mongodb.client.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;

public class DBliveryMongoRepository {

    @Autowired private MongoClient client;

    public void saveAssociation(PersistentObject source, PersistentObject destination, String associationName) {
        Association association = new Association(source.getObjectId(), destination.getObjectId());
        this.getDb()
                .getCollection(associationName, Association.class)
                .insertOne(association);
    }

    public MongoDatabase getDb() {
        return this.client.getDatabase("bd2_grupo12");
    }

    public <T extends PersistentObject> List<T> getAssociatedObjects(
            PersistentObject source, Class<T> objectClass, String association, String destCollection) {
        AggregateIterable<T> iterable =
                this.getDb()
                        .getCollection(association, objectClass)
                        .aggregate(
                                Arrays.asList(
                                        match(eq("source", source.getObjectId())),
                                        lookup(destCollection, "destination", "_id", "_matches"),
                                        unwind("$_matches"),
                                        replaceRoot("$_matches")));
        Stream<T> stream =
                StreamSupport.stream(Spliterators.spliteratorUnknownSize(iterable.iterator(), 0), false);
        return stream.collect(Collectors.toList());
    }

    public Product findProductById(ObjectId id) {
        Bson filter = eq("_id", id);
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        return collection.find(filter).first();
    }

    public User findUserById(ObjectId id) {
        Bson filter = eq("_id", id);
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        return collection.find(filter).first();
    }

    public User findUserByEmail(String email) {
        Bson filter = eq("email", email);
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        return collection.find(filter).first();
    }

    public User findUserByUsername(String username) {
        Bson filter = eq("username", username);
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        return collection.find(filter).first();
    }

//    public Order findOrderById(ObjectId orderId) {
//        Bson filter = eq("_id", orderId);
//        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
//        return collection.find(filter).first();
//    }

    public Order findOrderById(ObjectId id) {
        Bson filter = eq("_id", id);
        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
        Order result =  collection.find(filter).first();
        if (result.getId() != null){
            result = recreateOrder(result);
            return result;
        }
        return null;
    }

    private Order recreateOrder(Order order) {
        //Client User
        Bson filter = eq("source",order.getObjectId());
        MongoCollection<Association> collectionAssociationCU = getDb().getCollection("orderClientUser", Association.class);
        Association associationCU =collectionAssociationCU.find(filter).first();
        order.setClient(findUserById(associationCU.getDestination()));

        //Delivery User
        if(order.getDeliveryUser() != null) {
            MongoCollection<Association> collectionAssociationDU = getDb().getCollection("orderDeliverUser", Association.class);
            Association associationDU = collectionAssociationDU.find(filter).first();
            order.setClient(findUserById(associationDU.getDestination()));
        }
        return order;
    }

    public List<Product> getProductsByName(String name) {
        Bson filter = regex("name", name);
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        FindIterable<Product> productsItarable = collection.find(filter);
        List<Product> productsByName = new ArrayList<Product>();
        Iterator productIterator = productsItarable.iterator();
        while (productIterator.hasNext()){
            Product aProduct = (Product) productIterator.next();
                productsByName.add(aProduct);
        }
        return productsByName;
    }

    public Product saveProduct(Product product) {
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        collection.insertOne(product);
        return product;
    }

    public Supplier saveSupplier(Supplier supplier) {
        MongoCollection<Supplier> collection = getDb().getCollection("suppliers", Supplier.class);
        collection.insertOne(supplier);
        return supplier;
    }

    public User saveUser(User user) {
        MongoCollection<User> collection = getDb().getCollection("users", User.class);
        collection.insertOne(user);
        return user;
    }

//    public Order saveOrder(Order order) {
//        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
//        collection.insertOne(order);
//        return order;
//    }

    public Order saveOrder(Order order) {
        ObjectId objectId = new ObjectId();
        order.setObjectId(objectId);
        saveAssociation(order,order.getClient(), "orderClientUser");
        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
        collection.insertOne(order);
        return order;
    }


    public Product updateProduct(Product product) {
        Bson filter = eq("_id", product.getObjectId());
        MongoCollection<Product> collection = getDb().getCollection("products", Product.class);
        collection.replaceOne(filter, product);
        return collection.find(filter).first();
    }

    public Order updateOrder(Order order) {
        if(order.getDeliveryUser() != null){ saveAssociation(order,order.getDeliveryUser(), "orderDeliverUser");}
        Bson filter = eq("_id", order.getObjectId());
        MongoCollection<Order> collection = getDb().getCollection("orders", Order.class);
        collection.replaceOne(filter, order);
        return collection.find(filter).first();
    }
}