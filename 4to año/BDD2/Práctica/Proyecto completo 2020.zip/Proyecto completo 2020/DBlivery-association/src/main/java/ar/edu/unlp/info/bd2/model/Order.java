package ar.edu.unlp.info.bd2.model;
import java.util.*;

import ar.edu.unlp.info.bd2.mongo.PersistentObject;
import ar.edu.unlp.info.bd2.repositories.DBliveryException;
import org.bson.codecs.pojo.annotations.BsonDiscriminator;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.codecs.pojo.annotations.BsonIgnore;
import org.bson.types.ObjectId;

public class Order implements PersistentObject {
	@BsonId	private ObjectId id;
	private Set<OrderLine> orderLines = new HashSet<OrderLine>();
	private Set<OrderState> states = new HashSet<OrderState>();
	private User deliveryUser;
	private User client;
	private OrderState orderState;
	private String address;
	private Date dateOfOrder;
	private Float coordX;
	private Float coordY;
	private Float amount;

	public Order() {
	}

	public Order(Date dateOfOrder, String address, Float coordX,  Float coordY, User client) {
		setDateOfOrder(dateOfOrder);
		setClient(client);
		setAddress(address);
		setCoordX(coordX);
		setCoordY(coordY);
		Pending pending = new Pending(dateOfOrder);
		this.orderState = pending;
		addStates(pending);
	}

	public ObjectId getId() {
		return id;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public Set<OrderLine> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(Set<OrderLine> orderLines) {
		this.orderLines = orderLines;
	}

	public Set<OrderState> getStates() {
		return states;
	}

	public void setStates(Set<OrderState> states) {
		this.states = states;
	}

	public User getDeliveryUser() {
		return deliveryUser;
	}

	public void setDeliveryUser(User deliveryUser) {
		this.deliveryUser = deliveryUser;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public OrderState getOrderState() {
		return orderState;
	}

	public void setOrderState(OrderState orderState) {
		this.orderState = orderState;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDateOfOrder() {
		return dateOfOrder;
	}

	public void setDateOfOrder(Date dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}

	public Float getCoordX() {
		return coordX;
	}

	public void setCoordX(Float coordX) {
		this.coordX = coordX;
	}

	public Float getCoordY() {
		return coordY;
	}

	public void setCoordY(Float coordY) {
		this.coordY = coordY;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public Set<OrderState> getStatus() {
		return states;
	}

	@Override
	public ObjectId getObjectId() {
		return id;
	}

	@Override
	public void setObjectId(ObjectId objectId) {
		this.id=objectId;
	}

	public void addOrderLines(OrderLine orderLine) {
		getOrderLines().add(orderLine);
	}

	public Set<Product> allProducts() {
		Set<Product> products = new HashSet<Product>();
		Iterator orderLineIterator = getOrderLines().iterator();
		while (orderLineIterator.hasNext()){
			OrderLine anOrderLine = (OrderLine) orderLineIterator.next();
			products.add(anOrderLine.getProduct());
		}
		return products;
	}

	public void addStates(OrderState state) {
		getStates().add(state);
	}

	public void addOrderLine(long amount, Product product) {
		OrderLine newOrderLine = new OrderLine(amount, product);
		addOrderLines(newOrderLine);
	}

	public Boolean canDeliver() throws DBliveryException{
		if (this.getOrderLines().isEmpty()) throw new DBliveryException("Order can not delivered");
		return orderState.canDelivered();
	}

	public Boolean canFinish() {
		return getOrderState().canFinish();
	}

	public Boolean canCancel() {
		return getOrderState().canCancel();
	}

	public Boolean canSended() {
		return getOrderState().canSended();
	}

	public Order changeStatePending() throws DBliveryException {
		orderState.changePending(this);
		this.updateAmount();
		return this;
	}

	public Order changeStatePending(Date date) throws DBliveryException {
		getOrderState().changePending(this, date);
		this.updateAmount();
		return this;
	}
	
	public Order changeStateDelivered() throws DBliveryException {
		getOrderState().changeDelivered(this);
		this.updateAmount();
		return this;
	}
	
	public Order changeStateDelivered(Date date) throws DBliveryException {
		getOrderState().changeDelivered(this, date);
		this.updateAmount();
		return this;
	}

	public Order changeStateCanceled() throws DBliveryException {
		getOrderState().changeCanceled(this);
		this.updateAmount();
		return this;
	}

	public Order changeStateCanceled(Date date) throws DBliveryException {
		getOrderState().changeCanceled(this, date);
		this.updateAmount();
		return this;
	}

	public Order changeStateSended() throws DBliveryException {
		getOrderState().changeSended(this);
		this.updateAmount();
		return this;
	}

	public Order changeStateSended(Date date) throws DBliveryException {
		getOrderState().changeSended(this, date);
		this.updateAmount();
		return this;
	}

	public Order deliverOrder(User deliveryUser) throws DBliveryException {
		setDeliveryUser(deliveryUser);
		getOrderState().changeSended(this);
		return this;
	}

	public Order deliverOrder(User deliveryUser, Date date) throws DBliveryException {
		this.setDeliveryUser(deliveryUser);
		this.orderState.changeSended(this, date);
		return this;
	}

	public void updateAmount() {
		Float totalAmount = (float) 0;
		Iterator orderLineIterator = getOrderLines().iterator();
		while (orderLineIterator.hasNext()){
			OrderLine orderLine = (OrderLine) orderLineIterator.next();
			Set<Price> prices = orderLine.getProduct().getPrices();
			Iterator  i = prices.iterator();
			if(i.hasNext()){
				Price priOk = null;
				while (i.hasNext()){
					Price pri = (Price) i.next();
					if(getOrderState().getStartDate()!=null)
					{
						if((priOk==null  || (pri.getStartDate().after(priOk.getStartDate()))) &&  pri.getStartDate().before(getOrderState().getStartDate()))
							priOk = pri;
					}
					else
						priOk = pri;
				}
				float price = priOk.getValue();
				float amount = (float)orderLine.getAmount();
				totalAmount += amount*price;
			}
			else {
				totalAmount += orderLine.getProduct().getPrice();
			}
		}
		setAmount(totalAmount);
	}
	
	public void finish() throws DBliveryException {
		this.changeStateDelivered();
	}
	
	public void finish(Date date) throws DBliveryException {
		this.changeStateDelivered(date);
	}

	public void deliver(User deliveryUser) throws DBliveryException {
		if (getOrderLines().isEmpty()) throw new DBliveryException("Order can not delivered");
		setDeliveryUser(deliveryUser);
		changeStateSended();
	}

	public void deliver(User deliveryUser, Date date) throws DBliveryException {
		if (getOrderLines().isEmpty()) throw new DBliveryException("Order can not delivered");
		setDeliveryUser(deliveryUser);
		changeStateSended(date);
	}

	public void cancel() throws DBliveryException {
		this.changeStateCanceled();
	}

	public void cancel(Date date) throws DBliveryException {
		this.changeStateCanceled(date);
	}	
	
	public void sended() throws DBliveryException {
		this.changeStateSended();
	}
	
	public void sended(Date date) throws DBliveryException {
		this.changeStateSended(date);
	}

	public Set<Product> getProducts() {
		return this.allProducts();
	}
}
