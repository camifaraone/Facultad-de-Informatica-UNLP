package ar.edu.unlp.info.bd2.repositories;

public class DBliveryException extends Exception {

	public DBliveryException(String message) {
		super(message);
	}
}
