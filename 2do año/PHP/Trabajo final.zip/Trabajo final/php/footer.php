<hr color="#666">
<div id="contenedor">
	<div id="contenido">
		<img src="../img/mark2.jpg">
	</div>
</div>	

<div id="footer">
	<p id="pie">&copy; Reversa - Todos los derechos reservados 2015-2016</p>
</div>
			
