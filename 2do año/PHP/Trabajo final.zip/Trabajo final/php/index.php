<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" href="../img/icono.ico"/>
	<title>Reversa | Inicio</title>
	<link rel="stylesheet" type="text/css" href="css-js/estilo1.css">
</head>
<body>
	<div id="global">
	<?php
		include('header.php');
	?>
		<article>
			<aside>
				<div id="fotolateral">
					<img  class= "lateral" src="../img/gif.gif">
	            </div>
			</aside>
			<section>
				<div class="menu">
					<table>
	        			<tbody>
	            			<tr>
	                			<td>
	                    			
										<img  class= "imagen" src="../img/abrigo.png" alt="Reversa">
									
	                			</td>
	                			<td>
	                    			
										<img  class= "imagen" src="../img/accesorios.png" alt="Reversa">
									
	                			</td>
	                			<td>
	                    			
										<img  class= "imagen" src="../img/calzados.png" alt="Reversa">
									
	                			</td>
	            			</tr>
	            			<tr>
	                			<td>
	                    			
										<img class= "imagen" src="../img/monos.png" alt="Reversa">
									
                    			</td>
	                			<td>
	                   				
					   					<img class= "imagen" src="../img/pantalones.png" alt="Reversa">
					    			
	               				</td>
	                			<td>
	                    			
										<img class= "imagen" src="../img/remeras.png" alt="Reversa">
									
	                			</td>
	            			</tr>
	            			<tr>
                    			<td>
                        			
										<img class= "imagen" src="../img/polleras.png" alt="Reversa">
									
                    			</td>
	                			<td>
	                    			
										<img class= "imagen" src="../img/trajes.png" alt="Reversa">
									
	                			</td>
	                			<td>
	                    			
										<img class= "imagen" src="../img/vestidos.png" alt="Reversa">
									
	                			</td> 
	            			</tr>
	        			</tbody>
	    			</table>
	    		</div>
			</section>
			
		</article>
		
		<?php 
			include('footer.php');
		?>
		
	</div>
</body>
</html>
