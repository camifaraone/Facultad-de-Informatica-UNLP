function runSubmit (form)  {
		if (form.categoria.value ==""){
			alert("Ingrese categoria");
			return false;
		}
		return true;	
	}	
	
