#!/bin/bash
echo "Ingrese un nombre:"
read n1
echo "Ingrese otro nombre:"
read n2
echo $n1" ama a "$n2
