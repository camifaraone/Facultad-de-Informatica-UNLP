package tp06.test;

import tp02.ejercicio2.ListaGenerica;
import tp06.ejercicio4.Grafo;
import tp06.ejercicio4.GrafoImplListAdy;
import tp06.ejercicio4.Vertice;
import tp06.ejercicio4.VerticeImplListAdy;
import tp06.ejercicio5.Recorridos;

public class RecorridosTest {
	//Creo el grafo de la diapositiva de la teoria
	
	public static void main(String[] args) {
		Grafo <Integer> gr = new GrafoImplListAdy <Integer>();
		Vertice <Integer> uno = new VerticeImplListAdy <Integer>(1);
		gr.agregarVertice(uno);
		Vertice <Integer> dos = new VerticeImplListAdy <Integer>(2);
		gr.agregarVertice(dos);
		Vertice <Integer> tres = new VerticeImplListAdy <Integer>(3);
		gr.agregarVertice(tres);
		Vertice <Integer> cuatro = new VerticeImplListAdy <Integer>(4);
		gr.agregarVertice(cuatro);
		Vertice <Integer> cinco = new VerticeImplListAdy <Integer>(5);
		gr.agregarVertice(cinco);
		Vertice <Integer> seis = new VerticeImplListAdy <Integer>(6);
		gr.agregarVertice(seis);
		Vertice <Integer> siete = new VerticeImplListAdy <Integer>(7);
		gr.agregarVertice(siete);
		
		gr.conectar(uno, cuatro);
		gr.conectar(uno, dos);
		gr.conectar(uno, tres);
		gr.conectar(dos, cinco);
		gr.conectar(tres, cinco);
		gr.conectar(cuatro, seis);
		gr.conectar(cuatro, cinco);
		gr.conectar(cuatro, tres);
		gr.conectar(cuatro, dos);
		gr.conectar(cinco, siete);
		gr.conectar(seis, siete);
		gr.conectar(seis, tres);
		
		Recorridos<Integer> recorridos = new Recorridos<Integer>();
		
		ListaGenerica<Integer> listaTest = recorridos.dfs(gr);
		listaTest.comenzar();
		while(!listaTest.fin()) {
			System.out.print(listaTest.proximo());
		}
		System.out.println("");
		listaTest = recorridos.bfs(gr);
		listaTest.comenzar();
		while(!listaTest.fin()) {
			System.out.print(listaTest.proximo());
		}
	}

}
