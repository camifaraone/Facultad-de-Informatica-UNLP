package tp06.ejercicio5;

import tp02.ejercicio2.ColaGenerica;
import tp02.ejercicio2.ListaEnlazadaGenerica;
import tp02.ejercicio2.ListaGenerica;
import tp06.ejercicio4.Arista;
import tp06.ejercicio4.Grafo;
import tp06.ejercicio4.Vertice;

public class Recorridos<T> {
	
	public ListaGenerica<T> dfs(Grafo<T> grafo){
		ListaGenerica<T> resultado = new ListaEnlazadaGenerica<T>();
		if(!grafo.esVacio()) {
			boolean[] visitados = new boolean[grafo.listaDeVertices().tamanio()+1];
			ListaGenerica<Vertice<T>> listaDeVertices = grafo.listaDeVertices();
			listaDeVertices.comenzar();
			while(!listaDeVertices.fin()) {
				Vertice<T> vInicial = grafo.listaDeVertices().proximo();
				if(!visitados[vInicial.getPosicion()]) {
					dfs(vInicial,visitados,resultado,grafo);
				}
			}
		}
		return resultado;
	}

	private void dfs(Vertice<T> vActual, boolean[] visitados, ListaGenerica<T> resultado, Grafo<T> grafo) {
		visitados[vActual.getPosicion()] = true;
		resultado.agregarFinal(vActual.dato());
		ListaGenerica<Arista<T>> listaDeAdyacentes = grafo.listaDeAdyacentes(vActual);
		listaDeAdyacentes.comenzar();
		while(!listaDeAdyacentes.fin()) {
			Vertice<T> vSiguiente = listaDeAdyacentes.proximo().verticeDestino();
			if(!visitados[vSiguiente.getPosicion()]) {
				dfs(vSiguiente, visitados, resultado, grafo);
			}
		}
	}
	
	public ListaGenerica<T> bfs(Grafo<T> grafo){
		ListaGenerica<T> resultado = new ListaEnlazadaGenerica<T>();
		if(!grafo.esVacio()) {
			boolean[] visitados = new boolean[grafo.listaDeVertices().tamanio()+1];
			ListaGenerica<Vertice<T>> listaDeVertices = grafo.listaDeVertices();
			listaDeVertices.comenzar();
			while(!listaDeVertices.fin()) {
				Vertice<T> vInicial = grafo.listaDeVertices().proximo();
				if(!visitados[vInicial.getPosicion()]) {
					bfs(vInicial,visitados,resultado,grafo);
				}
			}
		}
		return resultado;
	}

	private void bfs(Vertice<T> vInicial, boolean[] visitados, ListaGenerica<T> resultado, Grafo<T> grafo) {
		ColaGenerica<Vertice<T>> cola = new ColaGenerica<Vertice<T>>();
		cola.encolar(vInicial);
		visitados[vInicial.getPosicion()] = true;
		while(!cola.esVacia()) {
			Vertice<T> vActual = cola.desencolar();
			resultado.agregarFinal(vActual.dato());
			ListaGenerica<Arista<T>> listaDeAdyacentes = grafo.listaDeAdyacentes(vActual);
			listaDeAdyacentes.comenzar();
			while(!listaDeAdyacentes.fin()) {
				Vertice<T> vSiguiente = listaDeAdyacentes.proximo().verticeDestino();
				if(!visitados[vSiguiente.getPosicion()]) {
					visitados[vSiguiente.getPosicion()] = true;
					cola.encolar(vSiguiente);
				}
			}
		}
	}
}
